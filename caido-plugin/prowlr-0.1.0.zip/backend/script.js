async function R(e) {
  const n = await e.meta.db();
  n.exec(`
    CREATE TABLE IF NOT EXISTS scope_rules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      pattern TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'include',
      active INTEGER NOT NULL DEFAULT 1
    )
  `), n.exec(`
    CREATE TABLE IF NOT EXISTS findings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      request_id TEXT,
      title TEXT NOT NULL,
      severity TEXT NOT NULL DEFAULT 'info',
      description TEXT,
      evidence TEXT,
      url TEXT,
      method TEXT,
      timestamp TEXT NOT NULL,
      exported INTEGER NOT NULL DEFAULT 0
    )
  `), n.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    )
  `);
  const t = n.prepare("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)");
  t.run("scope_enforcement", "warn"), t.run("ai_provider", "ollama"), t.run("claude_api_key", ""), t.run("claude_model", "claude-sonnet-4-20250514"), t.run("claude_endpoint", "https://api.anthropic.com/v1/messages"), t.run("ollama_endpoint", "http://localhost:11434"), t.run("ollama_model", "llama3.1"), t.run("obsidian_vault_path", "/vault");
}
function T(e, n) {
  const t = n.replace(/\./g, "\\.").replace(/\*/g, ".*");
  return new RegExp(`^${t}$`, "i").test(e);
}
async function w(e, n) {
  const t = await e.meta.db(), s = new URL(n).hostname, o = t.prepare(
    "SELECT * FROM scope_rules WHERE active = 1 ORDER BY type ASC"
  ).all();
  for (const a of o)
    if (a.type === "exclude" && T(s, a.pattern))
      return { inScope: !1, matchedRule: a.pattern };
  const r = o.filter((a) => a.type === "include");
  if (r.length === 0)
    return { inScope: !0, matchedRule: null };
  for (const a of r)
    if (T(s, a.pattern))
      return { inScope: !0, matchedRule: a.pattern };
  return { inScope: !1, matchedRule: null };
}
async function y(e) {
  return (await e.meta.db()).prepare("SELECT * FROM scope_rules ORDER BY type, pattern").all();
}
async function h(e, n, t) {
  const r = (await e.meta.db()).prepare("INSERT INTO scope_rules (pattern, type) VALUES (?, ?)").run(n, t), a = Number(r.lastInsertRowid);
  return e.console.log(`[Prowlr] Scope rule added: ${t} ${n}`), { id: a, pattern: n, type: t, active: !0 };
}
async function S(e, n) {
  (await e.meta.db()).prepare("DELETE FROM scope_rules WHERE id = ?").run(n);
}
async function O(e, n) {
  (await e.meta.db()).prepare("UPDATE scope_rules SET active = NOT active WHERE id = ?").run(n);
}
function E(e) {
  return Object.fromEntries(
    e.prepare("SELECT key, value FROM settings").all().map((n) => [n.key, n.value])
  );
}
const b = `You are a web security analyst reviewing HTTP traffic from a bug bounty engagement. Analyze this request/response pair for vulnerabilities.

REQUEST:
{REQUEST}

RESPONSE (first 4000 chars):
{RESPONSE}

Respond ONLY in JSON format (no markdown, no explanation outside the JSON):
{
  "summary": "one-line description of what this endpoint does",
  "findings": ["list of potential vulnerabilities or interesting behaviors"],
  "severity": "info|low|medium|high|critical",
  "recommendations": ["next steps to test/confirm each finding"]
}`;
async function $(e, n) {
  var i, c;
  const t = e.claude_api_key;
  if (!t)
    throw new Error("Claude API key not set — go to Prowlr settings");
  const s = e.claude_endpoint || "https://api.anthropic.com/v1/messages", o = e.claude_model || "claude-sonnet-4-20250514", r = await fetch(s, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": t,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: o,
      max_tokens: 1024,
      messages: [{ role: "user", content: n }]
    })
  });
  if (!r.ok) {
    const l = await r.text();
    throw new Error(`Claude ${r.status}: ${l.substring(0, 200)}`);
  }
  return ((c = (i = (await r.json()).content) == null ? void 0 : i[0]) == null ? void 0 : c.text) || "{}";
}
async function v(e, n) {
  const t = e.ollama_endpoint || "http://localhost:11434", s = e.ollama_model || "llama3.1", o = await fetch(`${t}/api/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: s,
      prompt: n,
      stream: !1,
      format: "json"
    })
  });
  if (!o.ok) {
    const a = await o.text();
    throw new Error(`Ollama ${o.status}: ${a.substring(0, 200)}`);
  }
  return (await o.json()).response || "{}";
}
async function N(e) {
  const n = await e.meta.db(), t = E(n), s = t.ai_provider || "ollama";
  try {
    if (s === "ollama") {
      const o = t.ollama_endpoint || "http://localhost:11434", r = await fetch(`${o}/api/tags`);
      if (!r.ok)
        throw new Error(`Ollama unreachable at ${o}`);
      return `Ollama OK — models: ${((await r.json()).models || []).map((c) => c.name).join(", ") || "none (pull one with: ollama pull llama3.1)"}`;
    } else {
      const o = t.claude_api_key;
      if (!o)
        return "Claude API key not set";
      const r = t.claude_endpoint || "https://api.anthropic.com/v1/messages", a = await fetch(r, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": o,
          "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify({
          model: t.claude_model || "claude-sonnet-4-20250514",
          max_tokens: 10,
          messages: [{ role: "user", content: "ping" }]
        })
      });
      if (!a.ok) {
        const i = await a.text();
        return `Claude auth failed (${a.status}): ${i.substring(0, 100)}`;
      }
      return `Claude OK — model: ${t.claude_model || "claude-sonnet-4-20250514"}`;
    }
  } catch (o) {
    return `Connection failed: ${o}`;
  }
}
async function L(e) {
  const n = await e.meta.db(), s = E(n).ollama_endpoint || "http://localhost:11434";
  try {
    const o = await fetch(`${s}/api/tags`);
    return o.ok ? ((await o.json()).models || []).map((a) => a.name) : [];
  } catch {
    return [];
  }
}
async function x(e, n) {
  const t = await e.meta.db(), s = E(t), o = s.ai_provider || "ollama", r = await e.requests.get(n);
  if (!r)
    return { summary: "Request not found", findings: [], severity: "info", recommendations: [] };
  const { request: a, response: i } = r, c = a.toSpecRaw().getRaw(), l = new TextDecoder().decode(c), p = i ? new TextDecoder().decode(i.getRaw()) : "(no response)", d = b.replace("{REQUEST}", l.substring(0, 4e3)).replace("{RESPONSE}", p.substring(0, 4e3));
  try {
    const u = o === "claude" ? await $(s, d) : await v(s, d), g = u.match(/\{[\s\S]*\}/);
    return g ? JSON.parse(g[0]) : { summary: u, findings: [], severity: "info", recommendations: [] };
  } catch (u) {
    return e.console.error(`[Prowlr] ${o} analysis failed: ${u}`), {
      summary: `${o} failed: ${u}`,
      findings: [],
      severity: "info",
      recommendations: []
    };
  }
}
async function _(e, n, t) {
  var d;
  const s = await e.meta.db(), o = await e.requests.get(n), r = o ? new URL(
    ((d = new TextDecoder().decode(o.request.toSpecRaw().getRaw()).split(`
`)[0]) == null ? void 0 : d.split(" ")[1]) || "/",
    "https://unknown"
  ).toString() : "unknown", a = o && new TextDecoder().decode(o.request.toSpecRaw().getRaw()).split(" ")[0] || "GET", i = (/* @__PURE__ */ new Date()).toISOString(), l = s.prepare(`
    INSERT INTO findings (request_id, title, severity, description, evidence, url, method, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    n,
    t.summary,
    t.severity,
    t.findings.join(`
`),
    t.recommendations.join(`
`),
    r,
    a,
    i
  ), p = Number(l.lastInsertRowid);
  return e.console.log(`[Prowlr] Finding saved: ${t.summary}`), {
    id: p,
    requestId: n,
    title: t.summary,
    severity: t.severity,
    description: t.findings.join(`
`),
    evidence: t.recommendations.join(`
`),
    url: r,
    method: a,
    timestamp: i,
    exported: !1
  };
}
async function f(e) {
  return (await e.meta.db()).prepare("SELECT * FROM findings ORDER BY timestamp DESC").all();
}
async function A(e, n) {
  (await e.meta.db()).prepare("DELETE FROM findings WHERE id = ?").run(n);
}
function m(e) {
  return `---
tags: [finding, ${e.severity}, caido]
severity: ${e.severity}
url: ${e.url}
method: ${e.method}
date: ${e.timestamp.split("T")[0]}
---

# ${e.title}

## Details
- **URL:** \`${e.url}\`
- **Method:** \`${e.method}\`
- **Severity:** ${e.severity.toUpperCase()}
- **Found:** ${e.timestamp}
- **Request ID:** ${e.requestId}

## Description
${e.description}

## Evidence / Next Steps
${e.evidence}

## Reproduction
1. Open Caido
2. Navigate to request ID \`${e.requestId}\`
3. Replay the request to confirm

## Notes

`;
}
async function I(e) {
  const t = (await f(e)).filter((i) => !i.exported);
  if (t.length === 0)
    return "No new findings to export.";
  const s = await e.meta.db(), o = "/home/hunter/exports/findings", r = [];
  for (const i of t) {
    m(i);
    const c = `finding-${i.id}-${i.severity}-${i.timestamp.split("T")[0]}.md`;
    r.push(`${c}: ${i.title}`), s.prepare("UPDATE findings SET exported = 1 WHERE id = ?").run(i.id);
  }
  const { execSync: a } = await import("child_process");
  try {
    a(`mkdir -p ${o}`);
    for (let i = 0; i < t.length; i++) {
      const c = t[i], l = m(c), p = `finding-${c.id}-${c.severity}-${c.timestamp.split("T")[0]}.md`, d = l.replace(/'/g, "'\\''");
      a(`cat > '${o}/${p}' << 'PROWLR_EOF'
${l}
PROWLR_EOF`);
    }
    return e.console.log(`[Prowlr] Exported ${t.length} findings to ${o}`), `Exported ${t.length} findings to ${o}:
${r.join(`
`)}`;
  } catch (i) {
    return e.console.log(`[Prowlr] Export write failed: ${i}`), `Write failed — copy manually:

${t.map(m).join(`
---

`)}`;
  }
}
async function C(e, n) {
  const s = (await e.meta.db()).prepare("SELECT value FROM settings WHERE key = ?").get(n);
  return (s == null ? void 0 : s.value) || "";
}
async function P(e, n, t) {
  (await e.meta.db()).prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)").run(n, t), e.console.log(`[Prowlr] Setting updated: ${n}`);
}
async function F(e) {
  await R(e), e.api.register("checkScope", w), e.api.register("getScopeRules", y), e.api.register("addScopeRule", h), e.api.register("removeScopeRule", S), e.api.register("toggleScopeRule", O), e.api.register("analyzeRequest", x), e.api.register("testAIConnection", N), e.api.register("getOllamaModels", L), e.api.register("saveAnalysisAsFinding", _), e.api.register("getFindings", f), e.api.register("deleteFinding", A), e.api.register("exportFindingsToObsidian", I), e.api.register("getSetting", C), e.api.register("setSetting", P), e.console.log("[Prowlr] Backend initialized");
}
export {
  F as init
};
