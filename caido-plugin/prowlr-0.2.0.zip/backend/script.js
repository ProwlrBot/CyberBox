async function R(e) {
  const n = await e.meta.db();
  n.exec(`
    CREATE TABLE IF NOT EXISTS scope_rules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      pattern TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'include',
      active INTEGER NOT NULL DEFAULT 1
    )
  `), n.exec(`
    CREATE TABLE IF NOT EXISTS findings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      request_id TEXT,
      title TEXT NOT NULL,
      severity TEXT NOT NULL DEFAULT 'info',
      description TEXT,
      evidence TEXT,
      url TEXT,
      method TEXT,
      timestamp TEXT NOT NULL,
      exported INTEGER NOT NULL DEFAULT 0
    )
  `), n.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    )
  `);
  const t = n.prepare("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)");
  t.run("scope_enforcement", "warn"), t.run("ai_provider", "ollama"), t.run("claude_api_key", ""), t.run("claude_model", "claude-sonnet-4-20250514"), t.run("claude_endpoint", "https://api.anthropic.com/v1/messages"), t.run("ollama_endpoint", "http://localhost:11434"), t.run("ollama_model", "llama3.1"), t.run("obsidian_vault_path", "/vault");
}
function T(e, n) {
  const t = n.replace(/\./g, "\\.").replace(/\*/g, ".*");
  return new RegExp(`^${t}$`, "i").test(e);
}
async function w(e, n) {
  const t = await e.meta.db(), i = new URL(n).hostname, a = t.prepare(
    "SELECT * FROM scope_rules WHERE active = 1 ORDER BY type ASC"
  ).all();
  for (const o of a)
    if (o.type === "exclude" && T(i, o.pattern))
      return { inScope: !1, matchedRule: o.pattern };
  const s = a.filter((o) => o.type === "include");
  if (s.length === 0)
    return { inScope: !0, matchedRule: null };
  for (const o of s)
    if (T(i, o.pattern))
      return { inScope: !0, matchedRule: o.pattern };
  return { inScope: !1, matchedRule: null };
}
async function y(e) {
  return (await e.meta.db()).prepare("SELECT * FROM scope_rules ORDER BY type, pattern").all();
}
async function S(e, n, t) {
  const s = (await e.meta.db()).prepare("INSERT INTO scope_rules (pattern, type) VALUES (?, ?)").run(n, t), o = Number(s.lastInsertRowid);
  return e.console.log(`[Prowlr] Scope rule added: ${t} ${n}`), { id: o, pattern: n, type: t, active: !0 };
}
async function b(e, n) {
  (await e.meta.db()).prepare("DELETE FROM scope_rules WHERE id = ?").run(n);
}
async function O(e, n) {
  (await e.meta.db()).prepare("UPDATE scope_rules SET active = NOT active WHERE id = ?").run(n);
}
function E(e) {
  return Object.fromEntries(
    e.prepare("SELECT key, value FROM settings").all().map((n) => [n.key, n.value])
  );
}
const v = `You are a web security analyst reviewing HTTP traffic from a bug bounty engagement. Analyze this request/response pair for vulnerabilities.

REQUEST:
{REQUEST}

RESPONSE (first 4000 chars):
{RESPONSE}

Respond ONLY in JSON format (no markdown, no explanation outside the JSON):
{
  "summary": "one-line description of what this endpoint does",
  "findings": ["list of potential vulnerabilities or interesting behaviors"],
  "severity": "info|low|medium|high|critical",
  "recommendations": ["next steps to test/confirm each finding"]
}`;
async function $(e, n) {
  var r, c;
  const t = e.claude_api_key;
  if (!t)
    throw new Error("Claude API key not set — go to Prowlr settings");
  const i = e.claude_endpoint || "https://api.anthropic.com/v1/messages", a = e.claude_model || "claude-sonnet-4-20250514", s = await fetch(i, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": t,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: a,
      max_tokens: 1024,
      messages: [{ role: "user", content: n }]
    })
  });
  if (!s.ok) {
    const p = await s.text();
    throw new Error(`Claude ${s.status}: ${p.substring(0, 200)}`);
  }
  return ((c = (r = (await s.json()).content) == null ? void 0 : r[0]) == null ? void 0 : c.text) || "{}";
}
async function N(e, n) {
  const t = e.ollama_endpoint || "http://localhost:11434", i = e.ollama_model || "llama3.1", a = await fetch(`${t}/api/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: i,
      prompt: n,
      stream: !1,
      format: "json"
    })
  });
  if (!a.ok) {
    const o = await a.text();
    throw new Error(`Ollama ${a.status}: ${o.substring(0, 200)}`);
  }
  return (await a.json()).response || "{}";
}
async function x(e) {
  const n = await e.meta.db(), t = E(n), i = t.ai_provider || "ollama";
  try {
    if (i === "ollama") {
      const a = t.ollama_endpoint || "http://localhost:11434", s = await fetch(`${a}/api/tags`);
      if (!s.ok)
        throw new Error(`Ollama unreachable at ${a}`);
      return `Ollama OK — models: ${((await s.json()).models || []).map((c) => c.name).join(", ") || "none (pull one with: ollama pull llama3.1)"}`;
    } else {
      const a = t.claude_api_key;
      if (!a)
        return "Claude API key not set";
      const s = t.claude_endpoint || "https://api.anthropic.com/v1/messages", o = await fetch(s, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": a,
          "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify({
          model: t.claude_model || "claude-sonnet-4-20250514",
          max_tokens: 10,
          messages: [{ role: "user", content: "ping" }]
        })
      });
      if (!o.ok) {
        const r = await o.text();
        return `Claude auth failed (${o.status}): ${r.substring(0, 100)}`;
      }
      return `Claude OK — model: ${t.claude_model || "claude-sonnet-4-20250514"}`;
    }
  } catch (a) {
    return `Connection failed: ${a}`;
  }
}
async function L(e) {
  const n = await e.meta.db(), i = E(n).ollama_endpoint || "http://localhost:11434";
  try {
    const a = await fetch(`${i}/api/tags`);
    return a.ok ? ((await a.json()).models || []).map((o) => o.name) : [];
  } catch {
    return [];
  }
}
async function A(e, n) {
  const t = await e.meta.db(), i = E(t), a = i.ai_provider || "ollama", s = await e.requests.get(n);
  if (!s)
    return { summary: "Request not found", findings: [], severity: "info", recommendations: [] };
  const { request: o, response: r } = s, c = o.toSpecRaw().getRaw(), p = new TextDecoder().decode(c), l = r ? new TextDecoder().decode(r.getRaw()) : "(no response)", d = v.replace("{REQUEST}", p.substring(0, 4e3)).replace("{RESPONSE}", l.substring(0, 4e3));
  try {
    const m = a === "claude" ? await $(i, d) : await N(i, d), f = m.match(/\{[\s\S]*\}/);
    return f ? JSON.parse(f[0]) : { summary: m, findings: [], severity: "info", recommendations: [] };
  } catch (m) {
    return e.console.error(`[Prowlr] ${a} analysis failed: ${m}`), {
      summary: `${a} failed: ${m}`,
      findings: [],
      severity: "info",
      recommendations: []
    };
  }
}
async function _(e, n, t) {
  var d;
  const i = await e.meta.db(), a = await e.requests.get(n), s = a ? new URL(
    ((d = new TextDecoder().decode(a.request.toSpecRaw().getRaw()).split(`
`)[0]) == null ? void 0 : d.split(" ")[1]) || "/",
    "https://unknown"
  ).toString() : "unknown", o = a && new TextDecoder().decode(a.request.toSpecRaw().getRaw()).split(" ")[0] || "GET", r = (/* @__PURE__ */ new Date()).toISOString(), p = i.prepare(`
    INSERT INTO findings (request_id, title, severity, description, evidence, url, method, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    n,
    t.summary,
    t.severity,
    t.findings.join(`
`),
    t.recommendations.join(`
`),
    s,
    o,
    r
  ), l = Number(p.lastInsertRowid);
  return e.console.log(`[Prowlr] Finding saved: ${t.summary}`), {
    id: l,
    requestId: n,
    title: t.summary,
    severity: t.severity,
    description: t.findings.join(`
`),
    evidence: t.recommendations.join(`
`),
    url: s,
    method: o,
    timestamp: r,
    exported: !1
  };
}
async function h(e) {
  return (await e.meta.db()).prepare("SELECT * FROM findings ORDER BY timestamp DESC").all();
}
async function C(e, n) {
  (await e.meta.db()).prepare("DELETE FROM findings WHERE id = ?").run(n);
}
function g(e) {
  return `---
tags: [finding, ${e.severity}, caido]
severity: ${e.severity}
url: ${e.url}
method: ${e.method}
date: ${e.timestamp.split("T")[0]}
---

# ${e.title}

## Details
- **URL:** \`${e.url}\`
- **Method:** \`${e.method}\`
- **Severity:** ${e.severity.toUpperCase()}
- **Found:** ${e.timestamp}
- **Request ID:** ${e.requestId}

## Description
${e.description}

## Evidence / Next Steps
${e.evidence}

## Reproduction
1. Open Caido
2. Navigate to request ID \`${e.requestId}\`
3. Replay the request to confirm

## Notes

`;
}
async function P(e) {
  const t = (await h(e)).filter((r) => !r.exported);
  if (t.length === 0)
    return "No new findings to export.";
  const i = await e.meta.db(), a = "/home/hunter/exports/findings", s = [];
  for (const r of t) {
    g(r);
    const c = `finding-${r.id}-${r.severity}-${r.timestamp.split("T")[0]}.md`;
    s.push(`${c}: ${r.title}`), i.prepare("UPDATE findings SET exported = 1 WHERE id = ?").run(r.id);
  }
  const { execSync: o } = await import("child_process");
  try {
    o(`mkdir -p ${a}`);
    for (let r = 0; r < t.length; r++) {
      const c = t[r], p = g(c), l = `finding-${c.id}-${c.severity}-${c.timestamp.split("T")[0]}.md`, d = p.replace(/'/g, "'\\''");
      o(`cat > '${a}/${l}' << 'PROWLR_EOF'
${p}
PROWLR_EOF`);
    }
    return e.console.log(`[Prowlr] Exported ${t.length} findings to ${a}`), `Exported ${t.length} findings to ${a}:
${s.join(`
`)}`;
  } catch (r) {
    return e.console.log(`[Prowlr] Export write failed: ${r}`), `Write failed — copy manually:

${t.map(g).join(`
---

`)}`;
  }
}
const u = /* @__PURE__ */ new Map();
async function U(e, n, t) {
  const { spawn: i } = await import("child_process"), a = u.get(n);
  if (a) {
    try {
      a.kill();
    } catch {
    }
    u.delete(n);
  }
  return new Promise((s) => {
    var c, p;
    const o = i("bash", ["-c", t], {
      cwd: process.env.HOME || "/home/hunter",
      env: { ...process.env, TERM: "xterm-256color", COLUMNS: "120", LINES: "30" }
    });
    u.set(n, o);
    let r = "";
    (c = o.stdout) == null || c.on("data", (l) => {
      const d = l.toString();
      r += d, e.api.send("terminal:output", n, d);
    }), (p = o.stderr) == null || p.on("data", (l) => {
      const d = l.toString();
      r += d, e.api.send("terminal:output", n, d);
    }), o.on("close", (l) => {
      u.delete(n), e.api.send("terminal:exit", n, l ?? 0), s(r);
    }), o.on("error", (l) => {
      u.delete(n), e.api.send("terminal:output", n, `\r
Error: ${l.message}\r
`), e.api.send("terminal:exit", n, 1), s(`Error: ${l.message}`);
    }), setTimeout(() => {
      if (u.has(n)) {
        try {
          o.kill();
        } catch {
        }
        u.delete(n);
      }
    }, 3e5);
  });
}
async function I(e, n, t) {
  var a;
  const i = u.get(n);
  (a = i == null ? void 0 : i.stdin) != null && a.writable && i.stdin.write(t);
}
async function F(e, n) {
  const t = u.get(n);
  if (t) {
    try {
      t.kill("SIGTERM");
    } catch {
    }
    u.delete(n);
  }
}
function D() {
  return [
    { label: "AI Analyze (Ollama)", cmd: "invoke-ollama", icon: "fas fa-robot" },
    { label: "AI Analyze (Claude)", cmd: "invoke-claude", icon: "fas fa-brain" },
    { label: "Harbinger Status", cmd: "harbinger status", icon: "fas fa-satellite-dish" },
    { label: "csbx List", cmd: "csbx list", icon: "fas fa-puzzle-piece" },
    { label: "Nuclei Scan", cmd: "echo 'Usage: nuclei -u <target>'", icon: "fas fa-search" },
    { label: "Subfinder", cmd: "echo 'Usage: subfinder -d <domain>'", icon: "fas fa-globe" },
    { label: "httpx Probe", cmd: "echo 'Usage: httpx -l hosts.txt'", icon: "fas fa-server" }
  ];
}
async function M(e, n) {
  const i = (await e.meta.db()).prepare("SELECT value FROM settings WHERE key = ?").get(n);
  return (i == null ? void 0 : i.value) || "";
}
async function j(e, n, t) {
  (await e.meta.db()).prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)").run(n, t), e.console.log(`[Prowlr] Setting updated: ${n}`);
}
async function q(e) {
  await R(e), e.api.register("checkScope", w), e.api.register("getScopeRules", y), e.api.register("addScopeRule", S), e.api.register("removeScopeRule", b), e.api.register("toggleScopeRule", O), e.api.register("analyzeRequest", A), e.api.register("testAIConnection", x), e.api.register("getOllamaModels", L), e.api.register("saveAnalysisAsFinding", _), e.api.register("getFindings", h), e.api.register("deleteFinding", C), e.api.register("exportFindingsToObsidian", P), e.api.register("getSetting", M), e.api.register("setSetting", j), e.api.register("terminalExec", U), e.api.register("terminalInput", I), e.api.register("terminalKill", F), e.api.register("getQuickCommands", D), e.console.log("[Prowlr] Backend initialized");
}
export {
  q as init
};
