var ProwlrFrontend=function(v){"use strict";const y="/prowlr",p={analyzeRequest:"prowlr.analyze-request",checkScope:"prowlr.check-scope",exportFindings:"prowlr.export-findings"};function h(e){var n,a,o,i,s,u,w;const t=document.createElement("div");return t.className="prowlr-container",t.innerHTML=`
    <div class="prowlr-header">
      <h1>Prowlr</h1>
      <p>Scope enforcement + AI analysis + Obsidian export</p>
    </div>

    <div class="prowlr-tabs">
      <button class="prowlr-tab active" data-tab="scope">Scope</button>
      <button class="prowlr-tab" data-tab="findings">Findings</button>
      <button class="prowlr-tab" data-tab="settings">Settings</button>
    </div>

    <div class="prowlr-panel" id="prowlr-scope">
      <div class="prowlr-scope-form">
        <input type="text" id="prowlr-scope-pattern" placeholder="*.example.com" />
        <select id="prowlr-scope-type">
          <option value="include">Include</option>
          <option value="exclude">Exclude</option>
        </select>
        <button id="prowlr-scope-add">Add Rule</button>
      </div>
      <div id="prowlr-scope-rules"></div>
    </div>

    <div class="prowlr-panel hidden" id="prowlr-findings">
      <div class="prowlr-findings-actions">
        <button id="prowlr-export-btn">Export to Obsidian</button>
        <button id="prowlr-refresh-findings">Refresh</button>
      </div>
      <div id="prowlr-findings-list"></div>
      <pre id="prowlr-export-output" class="hidden"></pre>
    </div>

    <div class="prowlr-panel hidden" id="prowlr-settings">
      <h3>General</h3>
      <div class="prowlr-setting">
        <label>Scope Enforcement</label>
        <select id="prowlr-setting-enforcement">
          <option value="warn">Warn (highlight out-of-scope)</option>
          <option value="off">Off</option>
        </select>
      </div>

      <h3>AI Provider</h3>
      <div class="prowlr-setting">
        <label>Provider</label>
        <select id="prowlr-setting-provider">
          <option value="ollama">Ollama (local)</option>
          <option value="claude">Claude (Anthropic API)</option>
        </select>
      </div>

      <div id="prowlr-ollama-settings">
        <div class="prowlr-setting">
          <label>Ollama Endpoint</label>
          <input type="text" id="prowlr-setting-ollama-endpoint" placeholder="http://localhost:11434" />
        </div>
        <div class="prowlr-setting">
          <label>Ollama Model</label>
          <select id="prowlr-setting-ollama-model">
            <option value="llama3.1">llama3.1</option>
          </select>
          <button id="prowlr-refresh-models" class="prowlr-btn-small">Refresh Models</button>
        </div>
      </div>

      <div id="prowlr-claude-settings" class="hidden">
        <div class="prowlr-setting">
          <label>API Key</label>
          <input type="password" id="prowlr-setting-claude-key" placeholder="sk-ant-api03-..." />
        </div>
        <div class="prowlr-setting">
          <label>Model</label>
          <select id="prowlr-setting-claude-model">
            <option value="claude-sonnet-4-20250514">Sonnet 4 (fast, cheap)</option>
            <option value="claude-opus-4-20250514">Opus 4 (best)</option>
            <option value="claude-haiku-4-5-20251001">Haiku 4.5 (fastest)</option>
          </select>
        </div>
        <div class="prowlr-setting">
          <label>Endpoint</label>
          <input type="text" id="prowlr-setting-claude-endpoint" placeholder="https://api.anthropic.com/v1/messages" />
        </div>
      </div>

      <div class="prowlr-settings-actions">
        <button id="prowlr-settings-save">Save Settings</button>
        <button id="prowlr-test-connection" class="prowlr-btn-secondary">Test Connection</button>
      </div>
      <div id="prowlr-connection-status"></div>
    </div>
  `,t.querySelectorAll(".prowlr-tab").forEach(l=>{l.addEventListener("click",()=>{var c;t.querySelectorAll(".prowlr-tab").forEach(d=>d.classList.remove("active")),t.querySelectorAll(".prowlr-panel").forEach(d=>d.classList.add("hidden")),l.classList.add("active");const r=l.dataset.tab;(c=t.querySelector(`#prowlr-${r}`))==null||c.classList.remove("hidden")})}),(n=t.querySelector("#prowlr-scope-add"))==null||n.addEventListener("click",async()=>{const l=t.querySelector("#prowlr-scope-pattern").value.trim(),r=t.querySelector("#prowlr-scope-type").value;l&&(await e.backend.addScopeRule(l,r),t.querySelector("#prowlr-scope-pattern").value="",await g(e,t))}),(a=t.querySelector("#prowlr-export-btn"))==null||a.addEventListener("click",async()=>{const l=await e.backend.exportFindingsToObsidian(),r=t.querySelector("#prowlr-export-output");r.textContent=l,r.classList.remove("hidden"),e.window.showToast("Findings exported — copy markdown to your vault",{variant:"success"})}),(o=t.querySelector("#prowlr-refresh-findings"))==null||o.addEventListener("click",()=>{m(e,t)}),(i=t.querySelector("#prowlr-setting-provider"))==null||i.addEventListener("change",l=>{const r=l.target.value,c=t.querySelector("#prowlr-ollama-settings"),d=t.querySelector("#prowlr-claude-settings");r==="ollama"?(c.classList.remove("hidden"),d.classList.add("hidden")):(c.classList.add("hidden"),d.classList.remove("hidden"))}),(s=t.querySelector("#prowlr-refresh-models"))==null||s.addEventListener("click",async()=>{const l=await e.backend.getOllamaModels(),r=t.querySelector("#prowlr-setting-ollama-model"),c=r.value;r.innerHTML=l.length?l.map(d=>`<option value="${d}" ${d===c?"selected":""}>${d}</option>`).join(""):'<option value="">No models found — run: ollama pull llama3.1</option>',e.window.showToast(`Found ${l.length} model(s)`,{variant:l.length?"success":"warning"})}),(u=t.querySelector("#prowlr-test-connection"))==null||u.addEventListener("click",async()=>{const l=t.querySelector("#prowlr-connection-status");l.textContent="Testing...",l.className="prowlr-status-testing",await b(e,t);const r=await e.backend.testAIConnection(),c=r.includes("OK");l.textContent=r,l.className=c?"prowlr-status-ok":"prowlr-status-error"}),(w=t.querySelector("#prowlr-settings-save"))==null||w.addEventListener("click",async()=>{await b(e,t),e.window.showToast("Settings saved",{variant:"success"})}),g(e,t),m(e,t),f(e,t),t}async function g(e,t){const n=await e.backend.getScopeRules(),a=t.querySelector("#prowlr-scope-rules");if(n.length===0){a.innerHTML='<p class="prowlr-empty">No scope rules. Add patterns to enforce scope.</p>';return}a.innerHTML=n.map(o=>`
    <div class="prowlr-rule ${o.type} ${o.active?"":"inactive"}">
      <span class="prowlr-rule-type">${o.type.toUpperCase()}</span>
      <span class="prowlr-rule-pattern">${o.pattern}</span>
      <button class="prowlr-rule-toggle" data-id="${o.id}">${o.active?"Disable":"Enable"}</button>
      <button class="prowlr-rule-delete" data-id="${o.id}">Delete</button>
    </div>
  `).join(""),a.querySelectorAll(".prowlr-rule-toggle").forEach(o=>{o.addEventListener("click",async()=>{await e.backend.toggleScopeRule(Number(o.dataset.id)),await g(e,t)})}),a.querySelectorAll(".prowlr-rule-delete").forEach(o=>{o.addEventListener("click",async()=>{await e.backend.removeScopeRule(Number(o.dataset.id)),await g(e,t)})})}async function m(e,t){const n=await e.backend.getFindings(),a=t.querySelector("#prowlr-findings-list");if(n.length===0){a.innerHTML='<p class="prowlr-empty">No findings yet. Right-click a request → Analyze with Prowlr.</p>';return}a.innerHTML=n.map(o=>`
    <div class="prowlr-finding severity-${o.severity}">
      <div class="prowlr-finding-header">
        <span class="prowlr-severity">${o.severity.toUpperCase()}</span>
        <span class="prowlr-finding-title">${o.title}</span>
        ${o.exported?'<span class="prowlr-exported">exported</span>':""}
      </div>
      <div class="prowlr-finding-meta">
        <code>${o.method} ${o.url}</code>
        <span>${o.timestamp.split("T")[0]}</span>
      </div>
      <div class="prowlr-finding-body">${o.description}</div>
      <button class="prowlr-finding-delete" data-id="${o.id}">Delete</button>
    </div>
  `).join(""),a.querySelectorAll(".prowlr-finding-delete").forEach(o=>{o.addEventListener("click",async()=>{await e.backend.deleteFinding(Number(o.dataset.id)),await m(e,t)})})}async function b(e,t){const n=t.querySelector("#prowlr-setting-enforcement").value,a=t.querySelector("#prowlr-setting-provider").value,o=t.querySelector("#prowlr-setting-ollama-endpoint").value,i=t.querySelector("#prowlr-setting-ollama-model").value,s=t.querySelector("#prowlr-setting-claude-key").value,u=t.querySelector("#prowlr-setting-claude-model").value,w=t.querySelector("#prowlr-setting-claude-endpoint").value;await e.backend.setSetting("scope_enforcement",n),await e.backend.setSetting("ai_provider",a),o&&await e.backend.setSetting("ollama_endpoint",o),i&&await e.backend.setSetting("ollama_model",i),s&&await e.backend.setSetting("claude_api_key",s),u&&await e.backend.setSetting("claude_model",u),w&&await e.backend.setSetting("claude_endpoint",w)}async function f(e,t){const n=await e.backend.getSetting("scope_enforcement"),a=await e.backend.getSetting("ai_provider"),o=await e.backend.getSetting("ollama_endpoint"),i=await e.backend.getSetting("ollama_model"),s=await e.backend.getSetting("claude_model"),u=await e.backend.getSetting("claude_endpoint");t.querySelector("#prowlr-setting-enforcement").value=n||"warn";const w=t.querySelector("#prowlr-setting-provider");if(w.value=a||"ollama",w.dispatchEvent(new Event("change")),t.querySelector("#prowlr-setting-ollama-endpoint").value=o||"http://localhost:11434",s&&(t.querySelector("#prowlr-setting-claude-model").value=s),u&&(t.querySelector("#prowlr-setting-claude-endpoint").value=u),!a||a==="ollama"){const l=await e.backend.getOllamaModels(),r=t.querySelector("#prowlr-setting-ollama-model");l.length&&(r.innerHTML=l.map(c=>`<option value="${c}" ${c===(i||"llama3.1")?"selected":""}>${c}</option>`).join(""))}}async function S(e,t){var a;const n=t.requests||(t.request?[t.request]:[]);if(n.length===0){e.window.showToast("No request selected",{variant:"warning"});return}e.window.showToast("Analyzing with AI...",{variant:"info"});for(const o of n){const i=typeof o=="string"?o:((a=o.getId)==null?void 0:a.call(o))||o.id,s=await e.backend.analyzeRequest(i);await e.backend.saveAnalysisAsFinding(i,s),e.window.showToast(`${s.severity.toUpperCase()}: ${s.summary}`,{variant:s.severity==="info"?"info":"warning"})}}async function q(e,t){var a;const n=t.requests||(t.request?[t.request]:[]);if(n.length!==0)for(const o of n){typeof o=="string"||(a=o.getId)!=null&&a.call(o)||o.id;const i=await e.backend.checkScope("https://placeholder.test");e.window.showToast(i.inScope?"In scope":`OUT OF SCOPE${i.matchedRule?` (${i.matchedRule})`:""}`,{variant:i.inScope?"success":"warning"})}}const E=e=>{e.commands.register(p.analyzeRequest,{name:"Analyze with Prowlr",run:n=>S(e,n)}),e.commands.register(p.checkScope,{name:"Check Scope",run:n=>q(e,n)}),e.commands.register(p.exportFindings,{name:"Export Findings to Obsidian",run:async()=>{const n=await e.backend.exportFindingsToObsidian();n.startsWith("No new")?e.window.showToast(n,{variant:"info"}):e.window.showToast("Findings exported",{variant:"success"})}}),e.menu.registerItem({type:"RequestRow",commandId:p.analyzeRequest,leadingIcon:"fas fa-brain"}),e.menu.registerItem({type:"RequestRow",commandId:p.checkScope,leadingIcon:"fas fa-crosshairs"}),e.menu.registerItem({type:"Request",commandId:p.analyzeRequest,leadingIcon:"fas fa-brain"}),e.commandPalette.register(p.analyzeRequest),e.commandPalette.register(p.exportFindings);const t=h(e);e.navigation.addPage(y,{body:t}),e.sidebar.registerItem("Prowlr",y,{icon:"fas fa-crosshairs"})};return v.init=E,Object.defineProperty(v,Symbol.toStringTag,{value:"Module"}),v}({});
